<?php
require('includes/dbh.inc.php');

$idComment=$_REQUEST['id'];

$query = "DELETE FROM gallery WHERE idComment='".$id."'";

$result = mysqli_query($conn, $query);

if($result){
    header("Location: designSelected.php");
}else {
    echo "Nu s-a sters!";
}
?>
