<?php
    session_start();
    $_SESSION['data']='Dormitor';
    header("Location:stiluri.php");
?>