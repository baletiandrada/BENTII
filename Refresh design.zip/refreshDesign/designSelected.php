<?php
  
  session_start();
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>My Portfolio</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900|Cormorant+Garamond:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
    <link rel="stylesheet" href="style3.css">
    <link href='https://fonts.googleapis.com/css?family=Allura' rel='stylesheet'>
  </head>
  <style>

.pozaComment  {
  display: inline-block>;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: flex-start;
  align-content: flex-start;
  float:left;
  margin-left:210px;
}

.pozaComment .firstA {
  width: 230px;
  margin: 20px 10px 0;
}

.pozaComment .firstA .anna {
  width: 500px;
  height: 500px;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}

.pozaComment .firstA  h3 {
  font-family: Catamaran;
  font-size: 20px;
  font-weight: 700;
  color: #111;
  padding-top: 16px;
  line-height: 26px;
}

.pozaComment .firstA  p {
  font-family: Catamaran;
  font-size: 16px;
  font-weight: 400;
  color: #111;
  padding-top: 4px;
  line-height: 20px;
}

/* COMMENTS */
#respond {
  margin-top: 40px;
}

#respond input[type='text'],
#respond input[type='email'], 
#respond textarea {
  margin-bottom: 10px;
  display: block;
  width: 100%;

  border: 1px solid rgba(0, 0, 0, 0.1);
  -webkit-border-radius: 5px;
  -moz-border-radius: 5px;
  -o-border-radius: 5px;
  -ms-border-radius: 5px;
  -khtml-border-radius: 5px;
  border-radius: 5px;

  line-height: 1.4em;
}
</style>

  <body>
  <header style="background-color:#427C9A;">
  <link rel="stylesheet" href="style.css"> 
  <nav class="nav-header-main">
    <a class="header-logo" href="index.php" style="margin-right: 110px;">
      <img src="img/logo.jpg" alt="hunt&Design logo">
    </a>
    <ul style="float:left;margin-top:8px;">
      <li><a href="index.php">Acasa</a></li>
      <li><a href="gallery.php">Galerie</a></li>
      <li><a href="aboutme.php">Despre</a></li>
      <li><a href="contact.php">Contact</a></li>
     
      <li><a href="javascript:window.print();">Printeaza Pagina</a></li>
    </ul>
  </nav>
  <div class="header-login">
        <?php
        if (!isset($_SESSION['id'])) {
          echo '<form action="includes/login.inc.php" method="post">
            <input type="text" name="mailuid" placeholder="E-mail/Username">
            <input type="password" name="pwd" placeholder="Password">
            <select id="mySelect" name="userType" style="font-size: 15px; margin-left: 10px;" >
                            <option>Designer</option>
                            <option>Client</option>
            </select> 
            <script>
              function myFunction() {
                var option = document.getElementById("mySelect").value;
                <?php echo $_POST["userType"];?> = option;
              }
            </script>
            <button type="submit" name="login-submit" style="color: #427C9A;">Login</button>
            <a href="signup.php">
              <button  type="submit" style="margin-left:10px; margin-right:10px; color: #427C9A;">Signup</button>
            </a>
          </form>
          ';
        }
        else if (isset($_SESSION['id'])) {
          echo '<form action="includes/logout.inc.php" method="post">
            <button style="background-color:#a9a9a9" type="submit" name="logout-submit">Logout</button>
          </form>';
        }
        ?>
      </div>
  </header>

    <main>
            <?php
            include_once 'includes/dbh.inc.php';
            $id=$_REQUEST['id'];
            $sql = "SELECT * FROM gallery WHERE idGallery='".$id."'";
            $stmt = mysqli_stmt_init($conn);
            if (!mysqli_stmt_prepare($stmt, $sql)) {
              echo "SQL statement failed!";
            }else{
              mysqli_stmt_execute($stmt);
              $result = mysqli_stmt_get_result($stmt);

              while ($row = mysqli_fetch_assoc($result)) {?>
              <div class="pozaComment">
                <a class="firstA">     
                     <div class="anna" style="background-image: url(img/gallery/<?php echo $row['imgFullNameGallery'];?>)"></div>
                    <?php
                    echo '
                          <h3>'.$row["titleGallery"].'</h3>
                          <p>'.$row["descGallery"].'</p>';   
                          ?>    
                         
                </a>
                <?php
                if (isset($_SESSION['uid'])) {?>
                <div>
                    <h3>Leave a Comment</h3>
                    <form action="includes/comments-inc.php?id=<?php echo $row['idGallery'];?>" method="post">
                        <label for="comment" class="required">Your message</label>
                        <textarea name="comment" id="comment" rows="10" tabindex="4"  required="required"></textarea>   
                        <input name="submit" type="submit" value="Submit comment" />
                    </form>
                </div>
                <?php } ?>

              </div>
              
               <?php      
              }
               


            }?>
            <div class="comentarii" style="float:right; margin-right:250px;">
                <?php
                $sql1=  "SELECT * FROM comments WHERE idGallery='".$id."'";
                $stmt1 = mysqli_stmt_init($conn);
                if (!mysqli_stmt_prepare($stmt1, $sql1)) {
                  echo "SQL statement failed!";
                }else{
                  mysqli_stmt_execute($stmt1);
                  $result1 = mysqli_stmt_get_result($stmt1);
    
                  while ($row1 = mysqli_fetch_assoc($result1)) {
                    echo '
                    <h3>'.$row1["nameUser"].'</h3>
                    <p>'.$row1["comment"].'</p>
                    ';
                  }
                }
            ?>
            </div>
            
    </main>
  </body>
</html>