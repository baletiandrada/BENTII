<?php
  session_start();
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>My Portfolio</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900|Cormorant+Garamond:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
    <link rel="stylesheet" href="style3.css">
    <link href='https://fonts.googleapis.com/css?family=Allura' rel='stylesheet'>
  </head>
  <style>
.gallery-links h2 {
  font-family: Catamaran;
  font-size: 28px;
  font-weight: 600;
  color: #111;
  text-transform: uppercase;
}

.gallery-container  {
  display: flex;
  flex-direction: row;
  flex-wrap: nowrap;
  justify-content: flex-start;
  align-content: flex-start;
}


.gallery-container .firstA {
  width: 230px;
  margin: 20px 10px 0;
}

.gallery-container .firstA :hover {
  opacity: 0.8;
}

.gallery-container .firstA .anna {
  width: 100%;
  height: 235px;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}

.gallery-container .firstA h3 {
  font-family: Catamaran;
  font-size: 20px;
  font-weight: 700;
  color: #111;
  padding-top: 16px;
  line-height: 26px;
}

.gallery-container .firstA p {
  font-family: Catamaran;
  font-size: 16px;
  font-weight: 400;
  color: #111;
  padding-top: 4px;
  line-height: 20px;
}

 .button2 {
  background-color:  #955649; 
  border: none;
  color: white;
  padding: 5px 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-family: 'Allura';
  font-size: 12px;
  cursor: pointer;
  border-radius: 50%;
}

.button2:hover {
  background-color:  #75706f ;
}




</style>

  <body>
  <header style="background-color:#427C9A;">
  <link rel="stylesheet" href="style.css"> 
  <nav class="nav-header-main">
    <a class="header-logo" href="index.php" style="margin-right: 110px;">
      <img src="img/logo.jpg" alt="hunt&Design logo">
    </a>
    <ul style="float:left;margin-top:8px;">
      <li><a href="index.php">Acasa</a></li>
      <li><a href="gallery.php">Galerie</a></li>
      <li><a href="aboutme.php">Despre</a></li>
      <li><a href="contact.php">Contact</a></li>
     
      <li><a href="javascript:window.print();">Printeaza Pagina</a></li>
    </ul>
  </nav>
  <div class="header-login">
        <?php
        if (!isset($_SESSION['id'])) {
          echo '<form action="includes/login.inc.php" method="post">
            <input type="text" name="mailuid" placeholder="E-mail/Username">
            <input type="password" name="pwd" placeholder="Password">
            <select id="mySelect" name="userType" style="font-size: 15px; margin-left: 10px;" >
                            <option>Designer</option>
                            <option>Client</option>
            </select> 
            <script>
              function myFunction() {
                var option = document.getElementById("mySelect").value;
                <?php echo $_POST["userType"];?> = option;
              }
            </script>
            <button type="submit" name="login-submit" style="color: #427C9A;">Login</button>
            <a href="signup.php">
              <button  type="submit" style="margin-left:10px; margin-right:10px; color: #427C9A;">Signup</button>
            </a>
          </form>
          ';
        }
        else if (isset($_SESSION['id'])) {
          echo '<form action="includes/logout.inc.php" method="post">
            <button style="background-color:#a9a9a9" type="submit" name="logout-submit">Logout</button>
          </form>';
        }
        ?>
      </div>
  </header>

    <main>
      <section class="gallery-links">
        <div class="wrapper">
          <h2>Gallery</h2>

          <div class="gallery-container">
            <?php
            include_once 'includes/dbh.inc.php';

            $sql = "SELECT * FROM gallery ORDER BY orderGallery DESC;";

            $stmt = mysqli_stmt_init($conn);
            if (!mysqli_stmt_prepare($stmt, $sql)) {
              echo "SQL statement failed!";
            }else{
              mysqli_stmt_execute($stmt);
              $result = mysqli_stmt_get_result($stmt);

              while ($row = mysqli_fetch_assoc($result)) {?>
                <a class="firstA" href="designSelected.php?id=<?php echo $row['idGallery'];?>">                   
                    <div class="anna" style="background-image: url(img/gallery/<?php echo $row['imgFullNameGallery'];?>)"></div>                    
                   
                    <?php
                    echo '
                          <h3>'.$row["titleGallery"].'</h3>
                          <p>'.$row["descGallery"].'</p>';
                          if (isset($_SESSION['uid']) && (strcmp($_SESSION['userType'], "Designer")==0) && (strcmp($_SESSION['uid'],$row['uidDesigners'])==0) ) {   
                          ?>  
                         <button class="button2" type="button" onclick="window.location.href='editare.php?id=<?php echo $row['idGallery'];?>'">Edit</button>
                         <button class="button2" type="button" onclick="window.location.href='delete.php?id=<?php echo $row['idGallery'];?>'" style=" margin-left: 15px;">Delete</button> 
                   </a>
                        
               <?php   
                          }        
              }
            }
            ?>
          </div>

          <?php

          if (isset($_SESSION['userType']) && strcmp($_SESSION['userType'], "Designer")==0 ) {
            echo '
            <div class="gallery-upload" style="margin-top:400px">
              <h2>Upload</h2>
              <form action="includes/gallery-upload.inc.php" method="post" enctype="multipart/form-data">
                <input type="text" name="filename" placeholder="File name...">
                <input type="text" name="filetitle" placeholder="Image title...">
                <input type="text" name="filedesc" placeholder="Image description...">
                <input type="file" name="file">
                <button type="submit" name="submit">UPLOAD</button>
              </form>
            </div>';
          }
          ?>

        </div>
      </section>
    </main>
  </body>
</html>