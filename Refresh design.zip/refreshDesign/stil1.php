<?php
    session_start();
    $_SESSION['data']='Bucatarie';
    header("Location:stiluri.php");
?>