<?php
    session_start();
    $_SESSION['data']='Salon';
    header("Location:stiluri.php");
?>