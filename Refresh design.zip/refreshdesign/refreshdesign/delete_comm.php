<?php
session_start();
require('includes/dbh.inc.php');
$idComment=$_REQUEST['id'];
$query = "DELETE FROM comments WHERE idComment='".$idComment."'";
$result = mysqli_query($conn, $query);

if($result){
    header("Location: designSelected.php?id=".$_SESSION['idGallery']);
}else {
    echo "Nu s-a sters!";
}

?>
