<!DOCTYPE html>
<html>
<?php
  session_start();
  if(isset($_SESSION['idGallery'])){
       unset($_SESSION['idGallery']);
    }
?>
  <head>
    <title>My Portfolio</title>   
    <link rel="stylesheet" href="design_selected.css"> 
  </head>

   <?php
       require "header.php";
     ?>

  <body>
    <main>
            <?php
            include_once 'includes/dbh.inc.php';
            $id=$_REQUEST['id'];
            $_SESSION['idGallery']=$id;
            $sql = "SELECT * FROM gallery WHERE idGallery='".$id."'";
            $stmt = mysqli_stmt_init($conn);
            if (!mysqli_stmt_prepare($stmt, $sql)) {
              echo "SQL statement failed!";
            }else{
              mysqli_stmt_execute($stmt);
              $result = mysqli_stmt_get_result($stmt);
              while ($row = mysqli_fetch_assoc($result)) {?>
              <div class="pozaComment">
                <a class="firstA">     
                     <div class="anna" style="background-image: url(img/gallery/<?php echo $row['imgFullNameGallery'];?>);"></div>
                        <center>
                    <?php
                    echo '
                          <h3>'.$row["titleGallery"].'</h3>
                          <p>'.$row["descGallery"].'</p><br>
                          <p style="color:#427C9A; font-size:20px"><b> Designer: ' .$row['uidDesigners'].' </b></p>'; ?>
                          <a href="allDesigns.php?id=<?php echo $row['uidDesigners'];?>" style="color: black;"> View all designs uploaded by <?php echo $row['uidDesigners'];?></a>                         
                        </center> 
                        
                </a><br>
                <?php
                if (isset($_SESSION['uid'])) {?>
                                                  <!-- Fixed button -->
                 <button class="comment_button" onclick="window.location.href='#comm'">Leave a comment</button>
                                                 <!-- ------------- -->
                <div>
                    <h3 style="margin-top: 20px; color: #955649; font-size: 25px;">Leave a Comment</h3>
                    <form action="includes/comments-inc.php?id=<?php echo $row['idGallery'];?>" method="post" id="respond">
                        <label for="comment" class="required" id="comm">Your message</label>
                        <textarea name="comment" id="comment" placeholder="Type message.." rows="10" tabindex="4"  required="required" style="margin-top:5px;"></textarea>
                        <center><input class="button2" name="submitComment" id="submitComment" type="submit" value="Submit comment" /></center>
                    </form>
                </div>
                <?php } ?>
              </div>
               <?php      
              }
            }
          if (isset($_SESSION['uid'])) {?>
            <div class="comentarii" style="float:right; margin-right:180px;">
                <center><h1 style="margin-bottom: 30px; font-size: 25px; margin-right:200px; font-family:Times New Roman">COMMENTS</h1></center>
                <?php
                $sql1=  "SELECT * FROM comments WHERE idGallery='".$id."'";
                $stmt1 = mysqli_stmt_init($conn);
                if (!mysqli_stmt_prepare($stmt1, $sql1)) {
                  echo "SQL statement failed!";
                }else{
                  mysqli_stmt_execute($stmt1);
                  $result1 = mysqli_stmt_get_result($stmt1);
                  // $index e folosit pentru multiplicarea chat-urilor
                  $index=1;

                  while ($row1 = mysqli_fetch_assoc($result1)) {
                    ?>
                    <h3> <?php echo $row1["nameUser"];?>: </h3>
                    <div class="Flex" style="display: flex;">
                         <p style="margin-left: 20px; margin-right:15px; max-width:400px;"><?php echo $row1["comment"];?></p>
                         <?php if (strcmp($_SESSION['uid'], $row1["nameUser"])==0 || strcmp($_SESSION['userType'], "Admin")==0) {
                                     ?>
                         <a href="delete_comm.php?id=<?php echo $row1['idComment'];?>">
                            <img border="0" src="img/delete_button.png" width="25" height="25">
                         </a> <?php
                         } ?>
                    <button class="open-button" onclick="openForm<?php echo $index;?>()" id="open-button<?php echo $index;?>">Reply</button>
                    </div>
                    <div class="chat-popup" id="myForm<?php echo $index;?>">
                      <form action="./includes/replyComm-inc.php?id=<?php echo $row1['idComment'];?>" class="form-container" method="post">
                        <label for="msg"><b>Your message reply</b></label>
                        <textarea id="replyComment" name="replyComment" placeholder="Type message.." required="required" ></textarea>
                        <button name="submitReply" id="submitReply" type="submit" class="btn">Send</button>
                        <button type="button" class="btn cancel" onclick="closeForm<?php echo $index;?>()">Close</button>
                      </form>
                    </div>
                    <?php
                        $sqlViewResp=  "SELECT * FROM reply_comments WHERE idComment='".$row1['idComment']."'";
                        $stmtV = mysqli_stmt_init($conn);
                        if (!mysqli_stmt_prepare($stmtV, $sqlViewResp)) {
                             echo "SQL statement failed!";
                        }else{
                                mysqli_stmt_execute($stmtV);
                                $resultV = mysqli_stmt_get_result($stmtV);
                                if ($rowV = mysqli_fetch_assoc($resultV)) {?>
                                   <center><input class="button2_modif" name="responses" onclick="openResponses<?php echo $index;?>()"
                                            id="responses<?php echo $index;?>" value="View responses" style="margin-top:25px; margin-bottom:30px;" />
                                   </center>
                          <?php }
                     }?>
                    </html>
                    <script>
                     function openForm<?php echo $index;?>() {
                           document.getElementById("open-button<?php echo $index;?>").style.display = "none";
                           document.getElementById("myForm<?php echo $index;?>").style.display = "block";
                      }
                     function closeForm<?php echo $index;?>() {
                          document.getElementById("myForm<?php echo $index;?>").style.display = "none";
                          document.getElementById("open-button<?php echo $index;?>").style.display = "block";
                      }
                     function openResponses<?php echo $index;?>() {
                          document.getElementById("responses<?php echo $index;?>").style.display = "none";
                          document.getElementById("div_responses<?php echo $index;?>").style.display = "block";
                          document.getElementById("close_responses<?php echo $index;?>").style.display = "block";
                      }
                      function closeResponses<?php echo $index;?>() {
                          document.getElementById("close_responses<?php echo $index;?>").style.display = "none";
                          document.getElementById("responses<?php echo $index;?>").style.display = "block";
                          document.getElementById("div_responses<?php echo $index;?>").style.display = "none";
                      }
                    </script>
                    <br><br>
                    <div class="reply-messages" id="reply-messages" style="margin-left: 45px; background-color: #E6ECF0;">
                    <?php
                        $sql2=  "SELECT * FROM reply_comments WHERE idComment='".$row1['idComment']."'";
                        $stmt2 = mysqli_stmt_init($conn);
                        if (!mysqli_stmt_prepare($stmt2, $sql2)) {
                             echo "SQL statement failed!";
                        }else{
                             mysqli_stmt_execute($stmt2);
                             $result2 = mysqli_stmt_get_result($stmt2);?>
                             <div id="div_responses<?php echo $index;?>" style="display: none;">
                            <?php while ($row2 = mysqli_fetch_assoc($result2)) {
                                                 ?>
                                <h3 style="margin-left: 10px;"> <?php echo $row2["nameUser"];?>: </h3>
                                <div style="display: flex;">
                                     <p style="margin-left: 20px; max-width:400px; margin-right:15px;"><?php echo $row2["replyComment"];?></p>
                                     <?php if ((strcmp($_SESSION['uid'], $row2["nameUser"])==0)||(strcmp($_SESSION['userType'], "Admin")==0)) {
                                                ?>
                                     <a href="delete_reply_comm.php?id=<?php echo $row2['idReply'];?>">
                                        <img border="0" src="img/delete_button.png" width="25" height="25">
                                     </a> <?php
                                     } ?>
                                </div><br>
                       <?php } ?> </div>
                            <center><input class="button2_modif" onclick="closeResponses<?php echo $index;?>()" id="close_responses<?php echo $index;?>" value="Hide responses" style="margin-top:25px; margin-bottom:30px; display:none;" /></center>
                            <?php } ?>
                    </div>

                 <?php 
                    $index= $index + 1;
                 }
                }

           } // if isset userName
           ?>
                   
            </div>
            
    </main>
  </body>
</html>