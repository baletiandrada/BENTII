<?php
    session_start();
    $_SESSION['data']='Baie';
    header("Location:stiluri.php");
?>